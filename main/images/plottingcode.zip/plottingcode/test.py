import pandas as pd
import numpy as np
from pathlib import Path
import re
import matplotlib.pyplot as plt

# =========================================================
# SETTINGS
# =========================================================
project_root = Path(__file__).resolve().parents[2]
data_path = project_root / "main" / "results" / "emission_per_run"

FIXED_RATE = 100.00
RATE_TOL = 1e-6
BASELINE_J = 1465.73   # your idle baseline in joules

# =========================================================
# HELPERS
# =========================================================
def extract_energy_j(file):
    df = pd.read_csv(file)

    if "energy_consumed" not in df.columns:
        return None

    df = df.dropna(subset=["energy_consumed"])
    if df.empty:
        return None

    return df["energy_consumed"].iloc[-1] * 3_600_000


def extract_lib(name):
    m = re.match(r"^([^_]+)", name)
    return m.group(1) if m else None


def extract_size(name):
    m = re.search(r"_size(\d+)", name)
    return int(m.group(1)) if m else None


def extract_rate(name):
    m = re.search(r"_rate([0-9]+(?:\.[0-9]+)?)", name)
    return float(m.group(1)) if m else None


def extract_rep(name):
    m = re.search(r"_rep(\d+)", name)
    return int(m.group(1)) if m else None


# =========================================================
# LOAD DATA
# =========================================================
rows = []

for file in data_path.glob("*.csv"):
    lib = extract_lib(file.name)
    size = extract_size(file.name)
    rate = extract_rate(file.name)
    rep = extract_rep(file.name)

    if None in [lib, size, rate, rep]:
        continue

    energy = extract_energy_j(file)
    if energy is None:
        continue

    rows.append({
        "lib": lib,
        "size": size,
        "rate": rate,
        "rep": rep,
        "energy_j": energy
    })

df = pd.DataFrame(rows)

# =========================================================
# FILTER FIXED RATE
# =========================================================
df = df[np.isclose(df["rate"], FIXED_RATE, atol=RATE_TOL)].copy()

if df.empty:
    print(f"No data found for fixed rate = {FIXED_RATE}")
    raise SystemExit

# =========================================================
# SUBTRACT BASELINE
# =========================================================
df["net_energy_j"] = df["energy_j"] - BASELINE_J

# =========================================================
# AVG ACROSS ALL REPS
# =========================================================
avg_df = (
    df.groupby(["lib", "size"])["net_energy_j"]
    .mean()
    .reset_index()
    .sort_values(["size", "lib"])
)

print("\n========== AVERAGE NET ENERGY ACROSS ALL REPS ==========\n")
print(avg_df)

# =========================================================
# PREPARE DATA FOR PLOTTING
# =========================================================
plot_df = avg_df.pivot(index="size", columns="lib", values="net_energy_j")
plot_df = plot_df.sort_index()

# =========================================================
# PLOT
# =========================================================
plt.figure(figsize=(10, 6))

for lib in plot_df.columns:
    plt.plot(
        plot_df.index,
        plot_df[lib],
        marker="o",
        linewidth=2,
        label=lib
    )

plt.xlabel("Message Size (bytes)")
plt.ylabel("Average Net Energy (J)")
plt.title(f"Average Net Energy vs Message Size (Fixed Rate = {FIXED_RATE})")
plt.xticks(plot_df.index)
plt.legend(title="Library")
plt.grid(True, linestyle="--", alpha=0.6)

plt.tight_layout()
plt.savefig("energy_vs_size_fixed_rate_all_reps_net.png", dpi=300, bbox_inches="tight")
print("\nPlot saved as: energy_vs_size_fixed_rate_all_reps_net.png")
